package q01.quiz01;

public class Quiz07_03 {
	public static void main(String[] args) {
		int score = 85;
		String result = (!(score > 90)) ? "가" : "나";	// 90보다 크지 않다면? 가
		System.out.println(result);
		
	}
}
