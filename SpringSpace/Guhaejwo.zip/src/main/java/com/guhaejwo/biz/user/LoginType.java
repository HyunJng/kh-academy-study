package com.guhaejwo.biz.user;

public enum LoginType {
	KAKAO,
	BASIC
}
