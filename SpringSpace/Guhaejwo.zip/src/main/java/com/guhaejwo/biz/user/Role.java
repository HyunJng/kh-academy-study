package com.guhaejwo.biz.user;

public enum Role {
	USER,
	ADMIN
}
